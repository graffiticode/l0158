# Change Log

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [v0.5.3] - 2024-07-12
### Added
- Added support for Authoraide API.

## [v0.5.2] - 2023-09-05
### Fixed
- Added support for expiry date in security object.

## [v0.5.1] - 2023-06-28
### Security
- Upgraded signature to match the security standard.

### Added
- This ChangeLog!
- Bumped mocha to 6.2.2
